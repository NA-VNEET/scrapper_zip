package org.narender.Web;

public class LoginService {

    public String login(String username, String password){
        LoginResponse response = new LoginResponse();


        return "JWTTTTTTTTTTTT";
    }
}
